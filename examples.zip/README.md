# Security Technician Wiki examples

Standalone examples from [securitytechnician.wiki](https://securitytechnician.wiki/).

Run commands from the repository or extracted archive root. Demos do not contact equipment. Python programs require Python 3.11 or later and use only the standard library. Other programs need their language toolchain.

For a small menu covering all ten Python demos:

```sh
python examples/run.py
```

To run and validate every Python demo in one pass:

```sh
python examples/run.py --test
```

## HTTPS JSON read

Read one HTTPS health endpoint with certificate validation and a bounded JSON response.

```sh
python examples/python/https_json.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/safe-https-json-python/)

## ONVIF device information

Send a read only GetDeviceInformation request to one ONVIF device service over HTTPS.

```sh
python examples/python/onvif_device_info.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/onvif-soap-request/)

## MQTT event validation

Check an MQTT topic and JSON event against a small, explicit application contract.

```sh
python examples/python/mqtt_event_contract.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/mqtt-event-contract/)

## Modbus register read

Read holding or input registers from one authorised Modbus TCP endpoint.

```sh
python examples/python/modbus_read.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/modbus-read-response/)

## RTSP and SDP inspection

Inspect the media descriptions in a saved RTSP DESCRIBE response.

```sh
python examples/python/rtsp_sdp.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/rtsp-sdp-inspection-python/)

## Event trace normalisation

Validate saved JSONL events and convert their occurrence timestamps to UTC.

```sh
python examples/python/trace_events.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/offline-trace-parsing-python/)

## Mutual TLS health client

Read a health endpoint using a validated server certificate and your own client certificate.

```sh
go run examples/go/mtls_health.go --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/mtls-client-go/)

## WebSocket event reader

Read a short stream of door state events over WSS using Node and its native WebSocket API.

```sh
tsc examples/typescript/websocket_events.ts --strict --target ES2022 --module commonjs --lib ES2022,DOM --outDir .example-build
node .example-build/websocket_events.js --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/websocket-events-typescript/)

## Modbus RTU frame and CRC

Check the size, fields and CRC of a captured Modbus RTU register response.

```sh
cc -std=c17 -Wall -Wextra -Werror -pedantic examples/c/modbus_crc.c -o modbus_crc
./modbus_crc --demo
./modbus_crc --self-test
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/binary-frame-crc-c/)

## Timestamp normalisation in C#

Keep event occurrence and receipt times separate while converting both to UTC.

```sh
dotnet run --project examples/csharp/Timestamps -- --demo
dotnet run --project examples/csharp/Timestamps -- --self-test
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/timestamp-normalization-csharp/)

## Video storage calculator

Estimate continuous recording capacity from measured bitrate, retention and free space requirements.

```sh
python examples/python/video_storage.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/video-storage-python/)

## TLS certificate expiry check

Check the certificate presented by one TLS endpoint without bypassing chain or hostname validation.

```sh
python examples/python/tls_expiry.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/tls-expiry-python/)

## SQLite event deduplication

Store an event once and detect an identity reused with different content.

```sh
python examples/python/event_store.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/event-store-python/)

## Webhook signature verification

Verify an HMAC signature over an unchanged request body and its timestamp.

```sh
python examples/python/webhook_hmac.py --demo
```

[Usage and limits](https://securitytechnician.wiki/05-development-and-integration/examples/webhook-hmac-python/)

## Licence

MIT. See `LICENSE.md`. Do not upload device credentials, private keys or real access records.
